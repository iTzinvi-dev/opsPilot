import React from 'react';
import { X, Send, CheckCircle2, AlertCircle, BookOpen, Terminal, ShieldCheck } from 'lucide-react';
import { RUNBOOKS } from '../data/scenarios';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  telegramEnabled: boolean;
  onToggleTelegram: (enabled: boolean) => void;
  onSendTestAlert: () => void;
  isSendingTest: boolean;
  groqConnected: boolean;
  telegramConnected: boolean;
}

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  onClose,
  telegramEnabled,
  onToggleTelegram,
  onSendTestAlert,
  isSendingTest,
  groqConnected,
  telegramConnected
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer panel */}
      <aside
        aria-label="Control Room Settings"
        className="relative z-10 w-full max-w-md bg-[#111723] border-l border-white/10 h-full flex flex-col justify-between overflow-y-auto shadow-2xl"
      >
        <div>
          {/* Drawer Header */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-white/[0.08]">
            <div>
              <p className="text-[11px] uppercase tracking-[0.14em] text-[#d4a95a] font-medium">
                Control Room Configuration
              </p>
              <h2 className="text-xl font-editorial font-semibold text-white mt-0.5">
                Settings &amp; Integrations
              </h2>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close settings drawer"
              className="w-11 h-11 rounded-xl border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-6">
            {/* Telegram Dispatch Controls */}
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-sans font-semibold text-white">
                    Telegram Alerts
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Dispatch incident summaries and proposed fixes when Responder completes.
                  </p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={telegramEnabled}
                  onClick={() => onToggleTelegram(!telegramEnabled)}
                  className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none min-w-[48px] min-h-[28px] items-center ${
                    telegramEnabled ? 'bg-[#d4a95a]' : 'bg-slate-700'
                  }`}
                >
                  <span className="sr-only">Toggle Telegram alerts</span>
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-[#0b0f17] shadow-md transition duration-200 ease-in-out ${
                      telegramEnabled ? 'translate-x-5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>

              <button
                type="button"
                onClick={onSendTestAlert}
                disabled={isSendingTest}
                className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.09] border border-white/10 text-xs font-medium text-slate-100 flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5 text-[#d4a95a]" />
                <span>{isSendingTest ? 'Dispatching Test Alert...' : 'Send Test Alert'}</span>
              </button>
            </section>

            <hr className="border-white/[0.08]" />

            {/* Server Integration Telemetry (Never exposes keys) */}
            <section className="space-y-3">
              <p className="text-[11px] uppercase tracking-[0.14em] text-slate-400 font-medium">
                Server-Side Connection Status
              </p>

              <div className="rounded-xl bg-[#0b0f17]/80 border border-white/[0.07] p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    {groqConnected ? (
                      <CheckCircle2 className="w-4 h-4 text-[#34d399] shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-[#fbbf24] shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p className="text-xs font-medium text-slate-200">
                        Groq LPU Inference Engine
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {groqConnected
                          ? 'Connected via GROQ_API_KEY (Llama 3.3 70B & DeepSeek R1 70B)'
                          : 'Standby · Using deterministic SRE fallback engine'}
                      </p>
                    </div>
                  </div>
                  <span
                    className={`text-[11px] font-mono shrink-0 ${
                      groqConnected ? 'text-[#34d399]' : 'text-[#fbbf24]'
                    }`}
                  >
                    {groqConnected ? 'Connected' : 'Fallback Ready'}
                  </span>
                </div>

                <div className="border-t border-white/[0.06] pt-3 flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    {telegramConnected ? (
                      <CheckCircle2 className="w-4 h-4 text-[#34d399] shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-[#fbbf24] shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p className="text-xs font-medium text-slate-200">
                        Telegram Bot API (sendMessage)
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {telegramConnected
                          ? 'Connected via server bot token & chat ID'
                          : 'In-app phone toast notification fallback active'}
                      </p>
                    </div>
                  </div>
                  <span
                    className={`text-[11px] font-mono shrink-0 ${
                      telegramConnected ? 'text-[#34d399]' : 'text-[#fbbf24]'
                    }`}
                  >
                    {telegramConnected ? 'Connected' : 'Toast Fallback'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#34d399] shrink-0" />
                <span>
                  All credentials remain isolated on the Node server and are never sent to the browser.
                </span>
              </div>
            </section>

            <hr className="border-white/[0.08]" />

            {/* Built-in Runbook Library Reference */}
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-[11px] uppercase tracking-[0.14em] text-slate-400 font-medium flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[#d4a95a]" />
                  <span>Built-in Runbook Registry (3 Entries)</span>
                </p>
              </div>

              <div className="space-y-2.5">
                {RUNBOOKS.map((rb) => (
                  <div
                    key={rb.id}
                    className="rounded-xl bg-[#0b0f17]/70 border border-white/[0.07] p-3.5 space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono font-medium text-[#d4a95a]">
                        {rb.id} · {rb.serviceName}
                      </span>
                      <span className="font-mono text-[11px] text-slate-400">
                        ~{rb.estimatedRecoverySec}s recovery
                      </span>
                    </div>
                    <p className="text-xs font-medium text-slate-200">{rb.title}</p>
                    <div className="flex items-center gap-1.5 pt-1 text-[11px] font-mono text-[#34d399]">
                      <Terminal className="w-3 h-3 shrink-0" />
                      <code className="truncate">{rb.fixCommand}</code>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </div>

        <div className="p-6 border-t border-white/[0.08] text-xs text-slate-500 flex items-center justify-between">
          <span>OpsPilot Control Room</span>
          <span className="font-mono">4-Agent Autonomous Pipeline</span>
        </div>
      </aside>
    </div>
  );
};
