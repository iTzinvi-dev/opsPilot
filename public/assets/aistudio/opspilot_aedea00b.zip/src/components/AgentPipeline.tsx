import React, { useState } from 'react';
import {
  Activity,
  ShieldAlert,
  Cpu,
  Send,
  CheckCircle2,
  Loader2,
  Terminal,
  BookOpen,
  Play,
  Copy,
  Check,
  Clock,
  ChevronDown,
  ChevronUp,
  Sparkles
} from 'lucide-react';
import {
  AgentRole,
  AgentState,
  RUNBOOKS,
  ServiceConfig
} from '../data/scenarios';

export interface AgentStepData {
  role: AgentRole;
  index: string;
  name: string;
  subtitle: string;
  model: string;
  state: AgentState;
  displayedText: string;
  fullText: string;
  durationMs?: number;
}

interface AgentPipelineProps {
  steps: AgentStepData[];
  activeService: ServiceConfig | null;
  pipelineStatus: 'idle' | 'running' | 'awaiting_approval' | 'executing_fix' | 'resolved' | 'acknowledged';
  executionProgress: number;
  executionStageText: string;
  resolutionTimeSec: number | null;
  onApproveFix: () => void;
  onIgnoreIncident: () => void;
  onRunLiveDemo: () => void;
  approvalCardRef: React.RefObject<HTMLDivElement | null>;
}

const AGENT_ICONS: Record<AgentRole, React.ReactNode> = {
  monitor: <Activity className="w-4 h-4" />,
  triage: <ShieldAlert className="w-4 h-4" />,
  diagnose: <Cpu className="w-4 h-4" />,
  responder: <Send className="w-4 h-4" />
};

export const AgentPipeline: React.FC<AgentPipelineProps> = ({
  steps,
  activeService,
  pipelineStatus,
  executionProgress,
  executionStageText,
  resolutionTimeSec,
  onApproveFix,
  onIgnoreIncident,
  onRunLiveDemo,
  approvalCardRef
}) => {
  const [showRunbooks, setShowRunbooks] = useState(false);
  const [copiedCommand, setCopiedCommand] = useState(false);

  const matchedRunbookId =
    steps.find((s) => s.role === 'diagnose')?.state === 'done'
      ? activeService?.runbookId
      : undefined;

  const handleCopyCommand = (cmd: string) => {
    navigator.clipboard?.writeText(cmd);
    setCopiedCommand(true);
    setTimeout(() => setCopiedCommand(false), 1800);
  };

  return (
    <div className="space-y-5">
      {/* Main Agent Pipeline Card */}
      <section className="control-card p-5 sm:p-6">
        {/* Section Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/[0.08]">
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em] text-[#d4a95a] font-medium">
              Autonomous Response Pipeline
            </p>
            <h2 className="text-xl font-editorial font-semibold text-white mt-0.5">
              4-Agent Diagnostic Timeline
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setShowRunbooks(!showRunbooks)}
              className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-xs font-medium text-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#d4a95a]" />
              <span>Runbooks (3)</span>
              {showRunbooks ? (
                <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              )}
            </button>
          </div>
        </div>

        {/* Collapsible Built-in Runbook Drawer */}
        {showRunbooks && (
          <div className="mt-4 rounded-xl bg-[#0b0f17]/90 border border-white/[0.08] p-4 space-y-3 transition-all duration-200">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="uppercase tracking-[0.12em] text-[11px] font-medium text-slate-300">
                Built-in Remediation Runbooks
              </span>
              <span className="font-mono text-[11px]">3 Verified Entries</span>
            </div>
            <div className="grid grid-cols-1 gap-2.5">
              {RUNBOOKS.map((rb) => {
                const isMatched = matchedRunbookId === rb.id;
                return (
                  <div
                    key={rb.id}
                    className={`rounded-xl p-3 border transition-colors ${
                      isMatched
                        ? 'bg-[#d4a95a]/10 border-[#d4a95a]/50'
                        : 'bg-[#111723]/70 border-white/[0.06]'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono font-semibold text-[#d4a95a]">
                          {rb.id}
                        </span>
                        <span className="text-slate-600" aria-hidden="true">·</span>
                        <span className="font-medium text-white">{rb.title}</span>
                      </div>
                      {isMatched && (
                        <span className="text-[11px] font-mono text-[#34d399]">
                          Matched by Diagnose Agent
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1">
                      Symptom: {rb.symptomSignature}
                    </p>
                    <div className="mt-2 flex items-center justify-between gap-2 text-[11px] font-mono text-[#34d399] bg-[#0b0f17] px-2.5 py-1.5 rounded-lg border border-white/[0.05]">
                      <code className="truncate">$ {rb.fixCommand}</code>
                      <span className="text-slate-500 shrink-0">target: {rb.serviceName}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Empty / Standby Hint Banner when Idle */}
        {pipelineStatus === 'idle' && (
          <div className="mt-4 rounded-xl bg-[#0b0f17]/75 border border-white/[0.07] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <p className="text-xs font-medium text-slate-200">
                Agents on Standby · Monitoring Telemetry Stream
              </p>
              <p className="text-xs text-slate-400">
                Trigger a failure on any service card or run the full live demo to watch the 4 agents collaborate.
              </p>
            </div>
            <button
              type="button"
              onClick={onRunLiveDemo}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-[#d4a95a]/15 hover:bg-[#d4a95a]/25 border border-[#d4a95a]/40 text-xs font-medium text-[#f3ce85] flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Trigger Live Demo</span>
            </button>
          </div>
        )}

        {/* Vertical Timeline of 4 Agents */}
        <div className="mt-6 space-y-0">
          {steps.map((step, idx) => {
            const isLast = idx === steps.length - 1;
            const isIdle = step.state === 'idle';
            const isThinking = step.state === 'thinking';
            const isTyping = step.state === 'typing';
            const isDone = step.state === 'done';
            const isActive = isThinking || isTyping;

            // Progress line state between this agent and the next
            const connectorProgress = isDone ? '100%' : isActive ? '50%' : '0%';

            return (
              <div key={step.role} className="relative flex gap-4">
                {/* Left Vertical Node & Animated Connecting Line */}
                <div className="flex flex-col items-center shrink-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center border transition-all duration-300 ${
                      isDone
                        ? 'bg-[#34d399]/15 border-[#34d399]/50 text-[#34d399]'
                        : isActive
                        ? 'bg-[#d4a95a]/20 border-[#d4a95a] text-[#d4a95a] shadow-[0_0_18px_rgba(212,169,90,0.3)]'
                        : 'bg-[#0b0f17] border-white/10 text-slate-500'
                    }`}
                  >
                    {isThinking ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : isDone ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      AGENT_ICONS[step.role]
                    )}
                  </div>

                  {!isLast && (
                    <div className="w-[2px] flex-1 min-h-[36px] bg-white/[0.08] my-1.5 relative overflow-hidden rounded-full">
                      <div
                        className="w-full bg-gradient-to-b from-[#d4a95a] to-[#34d399] transition-all duration-500 ease-out"
                        style={{ height: connectorProgress }}
                      />
                    </div>
                  )}
                </div>

                {/* Right Agent Content Box */}
                <div className={`flex-1 ${!isLast ? 'pb-6' : 'pb-1'} min-w-0`}>
                  <div
                    className={`rounded-xl border p-4 transition-all duration-300 ${
                      isActive
                        ? 'bg-[#151d2c] border-[#d4a95a]/45'
                        : isDone
                        ? 'bg-[#0e1420] border-white/[0.09]'
                        : 'bg-[#0b0f17]/50 border-white/[0.05]'
                    }`}
                  >
                    {/* Agent Header Row */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-[#d4a95a] font-medium">
                          {step.index}.
                        </span>
                        <h3 className="text-sm font-sans font-semibold text-white">
                          {step.name}
                        </h3>
                        <span className="text-slate-600 hidden sm:inline" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-xs text-slate-400 hidden sm:inline">
                          {step.subtitle}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-mono">
                        <span className="px-2 py-0.5 rounded-md bg-[#0b0f17] border border-white/[0.08] text-[11px] font-mono text-slate-300">
                          {step.model.replace('-instant', '').replace('-versatile', '')}
                          {step.durationMs ? ` · ${(step.durationMs / 1000).toFixed(1)}s` : ''}
                        </span>
                        {isIdle && (
                          <span className="text-slate-500">Standby</span>
                        )}
                        {isThinking && (
                          <span className="text-[#fbbf24] flex items-center gap-1.5">
                            <Sparkles className="w-3 h-3 animate-pulse" />
                            <span>Analyzing</span>
                          </span>
                        )}
                        {isTyping && (
                          <span className="text-[#d4a95a]">Streaming</span>
                        )}
                        {isDone && (
                          <span className="text-[#34d399]">Done</span>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-400 sm:hidden mt-0.5">
                      {step.subtitle}
                    </p>

                    {/* Agent Body State */}
                    <div className="mt-3">
                      {isIdle && (
                        <p className="text-xs text-slate-500 italic">
                          Awaiting upstream telemetry trigger...
                        </p>
                      )}

                      {isThinking && (
                        <div className="space-y-2 py-1" aria-label="Agent thinking skeleton">
                          <div className="h-3 w-11/12 rounded bg-white/[0.07] animate-pulse" />
                          <div className="h-3 w-4/5 rounded bg-white/[0.05] animate-pulse" />
                          <div className="h-3 w-3/5 rounded bg-white/[0.04] animate-pulse" />
                        </div>
                      )}

                      {(isTyping || isDone) && (
                        <div className="space-y-3">
                          <p className="text-sm text-slate-200 leading-relaxed font-normal">
                            {step.displayedText}
                            {isTyping && (
                              <span
                                className="inline-block w-1.5 h-4 ml-1 align-middle bg-[#d4a95a] animate-pulse"
                                aria-hidden="true"
                              />
                            )}
                          </p>

                          {/* Contextual Structured Metadata Footers per Agent Role */}
                          {isDone && activeService && step.role === 'triage' && (
                            <div className="pt-2 border-t border-white/[0.06] flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                              <span className="text-slate-400">Assigned Severity:</span>
                              <span
                                className={`font-mono font-semibold ${
                                  activeService.severity === 'Critical'
                                    ? 'text-[#f87171]'
                                    : activeService.severity === 'High'
                                    ? 'text-[#fbbf24]'
                                    : 'text-[#34d399]'
                                }`}
                              >
                                {activeService.severity}
                              </span>
                              <span className="text-slate-600" aria-hidden="true">·</span>
                              <span className="text-slate-300">{activeService.userImpact}</span>
                            </div>
                          )}

                          {isDone && activeService && step.role === 'diagnose' && (
                            <div className="pt-2 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-2 text-xs">
                              <div className="flex items-center gap-2 text-slate-300">
                                <BookOpen className="w-3.5 h-3.5 text-[#d4a95a] shrink-0" />
                                <span>
                                  Matched Runbook{' '}
                                  <strong className="font-mono text-[#d4a95a]">
                                    {activeService.runbookId}
                                  </strong>
                                </span>
                              </div>
                              <code className="font-mono text-[11px] text-[#34d399] bg-[#0b0f17] px-2.5 py-1 rounded-md border border-white/[0.06]">
                                $ {activeService.fixCommand}
                              </code>
                            </div>
                          )}

                          {isDone && activeService && step.role === 'responder' && (
                            <div className="pt-2 border-t border-white/[0.06] flex items-center gap-2 text-xs text-[#38bdf8]">
                              <Send className="w-3.5 h-3.5 shrink-0" />
                              <span>
                                On-call Telegram alert dispatched · Remediation staged for engineer sign-off
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Approval Card: Prominent Action Panel after Responder finishes */}
      {activeService &&
        (pipelineStatus === 'awaiting_approval' ||
          pipelineStatus === 'executing_fix' ||
          pipelineStatus === 'resolved' ||
          pipelineStatus === 'acknowledged') && (
          <div
            ref={approvalCardRef}
            className={`rounded-2xl p-5 sm:p-6 border transition-all duration-300 ${
              pipelineStatus === 'awaiting_approval'
                ? 'bg-[#151b29] border-[#d4a95a]/60 shadow-[0_0_35px_-8px_rgba(212,169,90,0.28)]'
                : pipelineStatus === 'executing_fix'
                ? 'bg-[#131b28] border-[#fbbf24]/50'
                : pipelineStatus === 'resolved'
                ? 'bg-[#101c1d] border-[#34d399]/45'
                : 'bg-[#171520] border-[#f87171]/40'
            }`}
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.14em] text-[#d4a95a] font-medium">
                  {pipelineStatus === 'awaiting_approval'
                    ? 'Human-in-the-Loop Sign-off Required'
                    : pipelineStatus === 'executing_fix'
                    ? 'Autonomous Remediation in Progress'
                    : pipelineStatus === 'resolved'
                    ? 'Incident Remediated & Verified'
                    : 'Incident Acknowledged · Fix Deferred'}
                </p>
                <h3 className="text-lg font-editorial font-semibold text-white mt-0.5">
                  {pipelineStatus === 'resolved'
                    ? `${activeService.name} Restored to Nominal Operation`
                    : pipelineStatus === 'acknowledged'
                    ? `${activeService.name} Alert Acknowledged (Unresolved)`
                    : `Proposed Fix for ${activeService.name}`}
                </h3>
              </div>

              {pipelineStatus === 'resolved' && resolutionTimeSec !== null && (
                <div className="flex items-center gap-1.5 text-xs font-mono text-[#34d399] bg-[#34d399]/10 px-3 py-1.5 rounded-lg border border-[#34d399]/30">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Resolved in {resolutionTimeSec}s</span>
                </div>
              )}
            </div>

            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              {activeService.rootCauseShort} Matched to{' '}
              <span className="font-mono text-[#d4a95a]">{activeService.runbookId}</span>.
            </p>

            {/* Code Block with Proposed Fix Command */}
            <div className="mt-4 rounded-xl bg-[#090d14] border border-white/10 p-3.5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0 font-mono text-xs sm:text-sm text-[#34d399]">
                <Terminal className="w-4 h-4 text-[#d4a95a] shrink-0" />
                <code className="truncate select-all">{activeService.fixCommand}</code>
              </div>
              <button
                type="button"
                onClick={() => handleCopyCommand(activeService.fixCommand)}
                aria-label="Copy remediation command"
                className="px-2.5 py-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-xs font-mono text-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                {copiedCommand ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#34d399]" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Executing Progress Bar */}
            {pipelineStatus === 'executing_fix' && (
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#fbbf24] flex items-center gap-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{executionStageText}</span>
                  </span>
                  <span className="text-slate-300">{executionProgress}%</span>
                </div>
                <div className="h-2 w-full rounded-full bg-[#0b0f17] overflow-hidden border border-white/10">
                  <div
                    className="h-full bg-gradient-to-r from-[#d4a95a] to-[#34d399] transition-all duration-200 ease-out"
                    style={{ width: `${executionProgress}%` }}
                  />
                </div>
              </div>
            )}

            {/* Action Buttons */}
            {pipelineStatus === 'awaiting_approval' && (
              <div className="mt-5 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <button
                  type="button"
                  onClick={onApproveFix}
                  className="flex-1 min-h-[46px] px-5 py-2.5 rounded-xl bg-[#34d399] hover:bg-[#2bc48a] text-[#07130e] font-semibold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg shadow-[#34d399]/15 whitespace-nowrap"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Approve Fix</span>
                </button>
                <button
                  type="button"
                  onClick={onIgnoreIncident}
                  className="sm:w-36 min-h-[46px] px-5 py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/15 text-slate-200 font-medium text-sm flex items-center justify-center transition-colors cursor-pointer whitespace-nowrap"
                >
                  Ignore
                </button>
              </div>
            )}
          </div>
        )}
    </div>
  );
};
