import React from 'react';
import { Send, CheckCircle2, X, ArrowDownRight, ShieldAlert } from 'lucide-react';

export interface TelegramToastData {
  id: string;
  type: 'telegram' | 'resolved' | 'acknowledged';
  title: string;
  subtitle: string;
  body: string;
  deliveredVia?: 'telegram' | 'fallback-toast' | 'disabled';
  timestamp: string;
}

interface PhoneToastProps {
  toast: TelegramToastData | null;
  onDismiss: () => void;
  onFocusApproval?: () => void;
  showFocusButton?: boolean;
}

export const PhoneToast: React.FC<PhoneToastProps> = ({
  toast,
  onDismiss,
  onFocusApproval,
  showFocusButton
}) => {
  if (!toast) return null;

  const isTelegram = toast.type === 'telegram';
  const isResolved = toast.type === 'resolved';

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed top-4 right-4 left-4 sm:left-auto sm:w-[400px] z-50 transition-all duration-300 ease-out animate-in fade-in slide-in-from-top-3"
    >
      <div className="rounded-2xl bg-[#131b2a]/95 backdrop-blur-xl border border-white/15 shadow-[0_24px_48px_-12px_rgba(0,0,0,0.85)] overflow-hidden">
        {/* Top subtle phone notification notch bar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-white/[0.03] border-b border-white/[0.07]">
          <div className="flex items-center gap-2">
            {isTelegram ? (
              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#38bdf8]/15 text-[#38bdf8]">
                <Send className="w-3 h-3" />
              </span>
            ) : isResolved ? (
              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#34d399]/15 text-[#34d399]">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </span>
            ) : (
              <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#fbbf24]/15 text-[#fbbf24]">
                <ShieldAlert className="w-3.5 h-3.5" />
              </span>
            )}
            <span className="text-[11px] font-medium uppercase tracking-[0.12em] text-slate-300">
              {toast.title}
            </span>
            <span className="text-slate-600" aria-hidden="true">·</span>
            <span className="text-[11px] font-mono text-slate-400">
              {toast.timestamp}
            </span>
          </div>
          <button
            type="button"
            onClick={onDismiss}
            aria-label="Dismiss notification"
            className="p-1.5 -mr-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors min-w-[32px] min-h-[32px] flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Notification body */}
        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-[#d4a95a]">
              {toast.subtitle}
            </span>
            {isTelegram && (
              <span className="text-[11px] font-mono text-slate-400">
                {toast.deliveredVia === 'telegram'
                  ? 'Telegram API · Sent'
                  : 'In-App Push · Fallback'}
              </span>
            )}
          </div>

          <pre className="text-xs font-mono text-slate-200 whitespace-pre-wrap leading-relaxed bg-[#0b0f17]/90 border border-white/[0.07] rounded-xl p-3">
            {toast.body}
          </pre>

          {isTelegram && showFocusButton && onFocusApproval && (
            <div className="mt-3 flex items-center justify-end">
              <button
                type="button"
                onClick={() => {
                  onFocusApproval();
                  onDismiss();
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-[#d4a95a] text-[#0b0f17] hover:bg-[#e0b86b] transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <span>Review &amp; Approve Fix</span>
                <ArrowDownRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
