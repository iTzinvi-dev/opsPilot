/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Activity,
  Settings,
  Play,
  Terminal,
  Server,
  Database,
  Globe,
  AlertTriangle,
  CheckCircle2,
  Clock,
  History,
  RotateCcw
} from 'lucide-react';
import {
  ServiceId,
  ServiceStatus,
  LogEntry,
  LogLevel,
  AgentRole,
  SERVICES_CONFIG,
  AMBIENT_HEALTHY_LOGS,
  INITIAL_INCIDENT_HISTORY,
  IncidentRecord
} from './data/scenarios';
import { AgentPipeline, AgentStepData } from './components/AgentPipeline';
import { SettingsDrawer } from './components/SettingsDrawer';
import { PhoneToast, TelegramToastData } from './components/PhoneToast';

const INITIAL_AGENT_STEPS: AgentStepData[] = [
  {
    role: 'monitor',
    index: '01',
    name: 'Monitor Agent',
    subtitle: 'Log stream anomaly detection',
    model: 'llama-3.1-8b-instant',
    state: 'idle',
    displayedText: '',
    fullText: ''
  },
  {
    role: 'triage',
    index: '02',
    name: 'Triage Agent',
    subtitle: 'Severity classification & blast radius',
    model: 'llama-3.1-8b-instant',
    state: 'idle',
    displayedText: '',
    fullText: ''
  },
  {
    role: 'diagnose',
    index: '03',
    name: 'Diagnose Agent',
    subtitle: 'Root cause analysis & runbook match',
    model: 'llama-3.3-70b-versatile',
    state: 'idle',
    displayedText: '',
    fullText: ''
  },
  {
    role: 'responder',
    index: '04',
    name: 'Responder Agent',
    subtitle: 'Incident synthesis & Telegram dispatch',
    model: 'llama-3.3-70b-versatile',
    state: 'idle',
    displayedText: '',
    fullText: ''
  }
];

function formatClock(date: Date): string {
  return date.toTimeString().split(' ')[0];
}

function createInitialLogs(): LogEntry[] {
  const now = Date.now();
  return AMBIENT_HEALTHY_LOGS.slice(0, 5).map((item, idx) => ({
    id: `init-${idx}`,
    timestamp: formatClock(new Date(now - (5 - idx) * 3000)),
    service: item.service,
    level: item.level,
    message: item.message
  }));
}

export default function App() {
  // Live clock
  const [currentTime, setCurrentTime] = useState<string>(() => formatClock(new Date()));

  // Services state
  const [serviceStatuses, setServiceStatuses] = useState<Record<ServiceId, ServiceStatus>>({
    web: 'healthy',
    api: 'healthy',
    database: 'healthy'
  });

  const [serviceLatencies, setServiceLatencies] = useState<Record<ServiceId, number>>({
    web: 26,
    api: 17,
    database: 6
  });

  // Logs state
  const [logs, setLogs] = useState<LogEntry[]>(createInitialLogs);
  const [logFilter, setLogFilter] = useState<'all' | 'errors'>('all');
  const logContainerRef = useRef<HTMLDivElement | null>(null);

  // Active Incident & Pipeline state
  const [activeServiceId, setActiveServiceId] = useState<ServiceId | null>(null);
  const [pipelineStatus, setPipelineStatus] = useState<
    'idle' | 'running' | 'awaiting_approval' | 'executing_fix' | 'resolved' | 'acknowledged'
  >('idle');
  const [agentSteps, setAgentSteps] = useState<AgentStepData[]>(INITIAL_AGENT_STEPS);
  const [incidentStartTimeMs, setIncidentStartTimeMs] = useState<number | null>(null);
  const [resolutionTimeSec, setResolutionTimeSec] = useState<number | null>(null);
  const [executionProgress, setExecutionProgress] = useState<number>(0);
  const [executionStageText, setExecutionStageText] = useState<string>('Initializing fix...');

  // History state
  const [incidentHistory, setIncidentHistory] = useState<IncidentRecord[]>(INITIAL_INCIDENT_HISTORY);

  // Settings & Server Connectivity state
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [telegramEnabled, setTelegramEnabled] = useState<boolean>(true);
  const [isSendingTestAlert, setIsSendingTestAlert] = useState<boolean>(false);
  const [groqConnected, setGroqConnected] = useState<boolean>(false);
  const [telegramConnected, setTelegramConnected] = useState<boolean>(false);

  // Phone-style Toast notification
  const [activeToast, setActiveToast] = useState<TelegramToastData | null>(null);

  // Refs for cancellation & scrolling
  const runIdRef = useRef<number>(0);
  const demoRotationRef = useRef<number>(0);
  const approvalCardRef = useRef<HTMLDivElement | null>(null);
  const pipelineSectionRef = useRef<HTMLDivElement | null>(null);

  const anyIncidentActive =
    serviceStatuses.web !== 'healthy' ||
    serviceStatuses.api !== 'healthy' ||
    serviceStatuses.database !== 'healthy';

  // 1. Live Clock Ticker
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(formatClock(new Date()));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // 2. Check Server Connectivity on Mount
  useEffect(() => {
    fetch('/api/status')
      .then((res) => res.json())
      .then((data) => {
        if (data && typeof data === 'object') {
          setGroqConnected(Boolean(data.groqConnected));
          setTelegramConnected(Boolean(data.telegramConnected));
        }
      })
      .catch(() => {
        setGroqConnected(false);
        setTelegramConnected(false);
      });
  }, []);

  // 3. Realistic Latency Fluctuation (slowly fluctuating when healthy, spiking when failing)
  useEffect(() => {
    const timer = setInterval(() => {
      setServiceLatencies((prev) => {
        const next: Record<ServiceId, number> = { ...prev };
        (['web', 'api', 'database'] as ServiceId[]).forEach((id) => {
          const cfg = SERVICES_CONFIG[id];
          const status = serviceStatuses[id];
          if (status === 'healthy') {
            const [min, max] = cfg.baseLatencyRange;
            const delta = Math.floor(Math.random() * 5) - 2;
            const candidate = prev[id] + delta;
            next[id] = Math.max(min, Math.min(max, candidate));
          } else {
            const [min, max] = cfg.failingLatencyRange;
            next[id] = Math.floor(min + Math.random() * (max - min));
          }
        });
        return next;
      });
    }, 1800);
    return () => clearInterval(timer);
  }, [serviceStatuses]);

  // 4. Ambient Log Generator while systems are operational
  useEffect(() => {
    const timer = setInterval(() => {
      if (pipelineStatus === 'running') return;
      const sample =
        AMBIENT_HEALTHY_LOGS[Math.floor(Math.random() * AMBIENT_HEALTHY_LOGS.length)];
      setLogs((prev) => [
        ...prev.slice(-75),
        {
          id: `amb-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          timestamp: formatClock(new Date()),
          service: sample.service,
          level: sample.level,
          message: sample.message
        }
      ]);
    }, 3800);
    return () => clearInterval(timer);
  }, [pipelineStatus]);

  // Auto-scroll terminal log stream
  useEffect(() => {
    const el = logContainerRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [logs, logFilter]);

  const appendLog = useCallback((service: string, level: LogLevel, message: string) => {
    setLogs((prev) => [
      ...prev.slice(-85),
      {
        id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        timestamp: formatClock(new Date()),
        service,
        level,
        message
      }
    ]);
  }, []);

  // Helper to run typewriter effect for a single agent step
  const animateAgentText = useCallback(
    (role: AgentRole, fullText: string, durationMs: number, currentRunId: number): Promise<void> => {
      return new Promise((resolve) => {
        setAgentSteps((prev) =>
          prev.map((step) =>
            step.role === role
              ? { ...step, state: 'typing', fullText, displayedText: '', durationMs }
              : step
          )
        );

        let charIndex = 0;
        const stepSize = 3; // 3 chars per tick for snappy ~2.2s typing
        const interval = setInterval(() => {
          if (runIdRef.current !== currentRunId) {
            clearInterval(interval);
            resolve();
            return;
          }
          charIndex = Math.min(fullText.length, charIndex + stepSize);
          const sliced = fullText.slice(0, charIndex);

          setAgentSteps((prev) =>
            prev.map((step) =>
              step.role === role
                ? {
                    ...step,
                    displayedText: sliced,
                    state: charIndex >= fullText.length ? 'done' : 'typing'
                  }
                : step
            )
          );

          if (charIndex >= fullText.length) {
            clearInterval(interval);
            resolve();
          }
        }, 18);
      });
    },
    []
  );

  // Send Telegram Alert via server /api/telegram + show PhoneToast
  const dispatchTelegramAlert = useCallback(
    async (serviceId: ServiceId) => {
      const cfg = SERVICES_CONFIG[serviceId];
      const exactAlertMessage = [
        '🚨 OpsPilot Alert',
        `Service: ${cfg.name}`,
        `Severity: ${cfg.severity}`,
        `Root cause: ${cfg.rootCauseShort}`,
        `Proposed fix: ${cfg.fixCommand}`,
        'Open OpsPilot to approve.'
      ].join('\n');

      if (!telegramEnabled) {
        appendLog('opspilot-responder', 'INFO', 'Telegram alerts muted in Settings; awaiting in-app approval.');
        return;
      }

      try {
        const res = await fetch('/api/telegram', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            serviceName: cfg.name,
            severity: cfg.severity,
            rootCause: cfg.rootCauseShort,
            proposedFix: cfg.fixCommand,
            customMessage: exactAlertMessage
          })
        });
        const data = await res.json();
        setActiveToast({
          id: `tg-${Date.now()}`,
          type: 'telegram',
          title: 'Telegram · OpsPilot Bot',
          subtitle: `Incident Alert · ${cfg.name}`,
          body: data.alertText || exactAlertMessage,
          deliveredVia: data.deliveredVia || 'fallback-toast',
          timestamp: formatClock(new Date())
        });
      } catch {
        setActiveToast({
          id: `tg-${Date.now()}`,
          type: 'telegram',
          title: 'Telegram · OpsPilot Bot',
          subtitle: `Incident Alert · ${cfg.name}`,
          body: exactAlertMessage,
          deliveredVia: 'fallback-toast',
          timestamp: formatClock(new Date())
        });
      }
    },
    [telegramEnabled, appendLog]
  );

  // Trigger a failure scenario on a specific service and run the 4-agent pipeline
  const triggerIncident = useCallback(
    async (serviceId: ServiceId) => {
      const currentRunId = ++runIdRef.current;
      const cfg = SERVICES_CONFIG[serviceId];
      const startTime = Date.now();

      setIncidentStartTimeMs(startTime);
      setResolutionTimeSec(null);
      setActiveServiceId(serviceId);
      setPipelineStatus('running');
      setLogFilter('all');

      // Mark target service as failing (and reset any previously failing service so focus is clean)
      setServiceStatuses({
        web: serviceId === 'web' ? 'failing' : 'healthy',
        api: serviceId === 'api' ? 'failing' : 'healthy',
        database: serviceId === 'database' ? 'failing' : 'healthy'
      });

      // Spike latency immediately on the failing service
      setServiceLatencies((prev) => ({
        ...prev,
        [serviceId]: cfg.failingLatencyRange[0] + 240
      }));

      // Reset all 4 agent steps to idle
      setAgentSteps(
        INITIAL_AGENT_STEPS.map((s) => ({
          ...s,
          state: 'idle',
          displayedText: '',
          fullText: '',
          durationMs: undefined
        }))
      );

      // Smoothly scroll pipeline into view on smaller screens
      if (window.innerWidth < 1024 && pipelineSectionRef.current) {
        setTimeout(() => {
          pipelineSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 150);
      }

      // Burst the 9-10 realistic error log lines sequentially over ~1.2s
      const logLinesStrings: string[] = [];
      for (let i = 0; i < cfg.errorLogs.length; i++) {
        if (runIdRef.current !== currentRunId) return;
        const entry = cfg.errorLogs[i];
        logLinesStrings.push(`${entry.level}: ${entry.message}`);
        appendLog(cfg.id, entry.level, entry.message);
        await new Promise((r) => setTimeout(r, 110));
      }

      // Sequentially run the 4 agents: Monitor -> Triage -> Diagnose -> Responder
      const rolesOrder: AgentRole[] = ['monitor', 'triage', 'diagnose', 'responder'];
      const accumulatedOutputs: Partial<Record<AgentRole, string>> = {};

      for (const role of rolesOrder) {
        if (runIdRef.current !== currentRunId) return;

        // Set current agent to thinking
        setAgentSteps((prev) =>
          prev.map((step) => (step.role === role ? { ...step, state: 'thinking' } : step))
        );

        const stepStart = Date.now();
        let agentOutputText = cfg.fallbackAgentOutputs[role];
        let serverLatencyMs: number | undefined;

        try {
          const [res] = await Promise.all([
            fetch('/api/agent', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                agentRole: role,
                serviceId: cfg.id,
                serviceName: cfg.name,
                scenarioTitle: cfg.failureScenarioTitle,
                logs: logLinesStrings,
                previousOutputs: accumulatedOutputs
              })
            }),
            // Ensure at least 400ms of visible "thinking" state for visual clarity
            new Promise((r) => setTimeout(r, 400))
          ]);

          if (res.ok) {
            const data = await res.json();
            if (data?.output && typeof data.output === 'string') {
              agentOutputText = data.output;
            }
            if (typeof data?.latencyMs === 'number') {
              serverLatencyMs = data.latencyMs;
            }
            if (data?.model && typeof data.model === 'string') {
              setAgentSteps((prev) =>
                prev.map((step) =>
                  step.role === role ? { ...step, model: data.model } : step
                )
              );
            }
          }
        } catch {
          // Graceful fallback if network request fails
          await new Promise((r) => setTimeout(r, 400));
        }

        if (runIdRef.current !== currentRunId) return;

        accumulatedOutputs[role] = agentOutputText;
        const stepDuration = serverLatencyMs ?? (Date.now() - stepStart);

        // Type out the agent's output with typewriter effect
        await animateAgentText(role, agentOutputText, stepDuration, currentRunId);
      }

      if (runIdRef.current !== currentRunId) return;

      // Responder finished: dispatch Telegram alert & show Approval Card
      appendLog(
        'opspilot-responder',
        'WARN',
        `Incident staged (${cfg.runbookId}): awaiting engineer approval for "${cfg.fixCommand}"`
      );
      await dispatchTelegramAlert(serviceId);

      if (runIdRef.current !== currentRunId) return;
      setPipelineStatus('awaiting_approval');
    },
    [appendLog, animateAgentText, dispatchTelegramAlert]
  );

  // Run Live Demo button handler: rotates through services or picks one and runs pipeline
  const handleRunLiveDemo = useCallback(() => {
    const order: ServiceId[] = ['api', 'web', 'database'];
    const nextService = order[demoRotationRef.current % order.length];
    demoRotationRef.current += 1;
    triggerIncident(nextService);
  }, [triggerIncident]);

  // Approve Fix button handler
  const handleApproveFix = useCallback(async () => {
    if (!activeServiceId || pipelineStatus !== 'awaiting_approval') return;
    const cfg = SERVICES_CONFIG[activeServiceId];
    const currentRunId = runIdRef.current;

    setPipelineStatus('executing_fix');
    setExecutionProgress(15);
    setExecutionStageText(`Executing: ${cfg.fixCommand}...`);

    // Emit recovery logs while progress bar advances
    const stages = [
      { progress: 42, text: 'Draining stalled worker sockets...' },
      { progress: 74, text: 'Restarting container & reloading pool...' },
      { progress: 96, text: 'Running synthetic readiness probes...' }
    ];

    for (let i = 0; i < stages.length; i++) {
      await new Promise((r) => setTimeout(r, 550));
      if (runIdRef.current !== currentRunId) return;
      setExecutionProgress(stages[i].progress);
      setExecutionStageText(stages[i].text);
      if (cfg.recoveryLogs[i]) {
        appendLog(cfg.id, cfg.recoveryLogs[i].level, cfg.recoveryLogs[i].message);
      }
    }

    await new Promise((r) => setTimeout(r, 450));
    if (runIdRef.current !== currentRunId) return;

    if (cfg.recoveryLogs[3]) {
      appendLog(cfg.id, cfg.recoveryLogs[3].level, cfg.recoveryLogs[3].message);
    }

    setExecutionProgress(100);

    const elapsedSec = incidentStartTimeMs
      ? Math.max(12, Math.round((Date.now() - incidentStartTimeMs) / 1000))
      : 28;

    setResolutionTimeSec(elapsedSec);
    setPipelineStatus('resolved');

    // Restore service health & normalize latency
    setServiceStatuses((prev) => ({
      ...prev,
      [activeServiceId]: 'healthy'
    }));
    setServiceLatencies((prev) => ({
      ...prev,
      [activeServiceId]: cfg.baseLatencyRange[0] + 2
    }));

    // Record in Incident History
    const newRecord: IncidentRecord = {
      id: `INC-${Math.floor(8500 + Math.random() * 499)}`,
      timestamp: `Just now · ${formatClock(new Date())}`,
      serviceId: activeServiceId,
      serviceName: cfg.name,
      severity: cfg.severity,
      rootCause: cfg.rootCauseShort,
      proposedFix: cfg.fixCommand,
      runbookId: cfg.runbookId,
      status: 'Resolved',
      resolutionSeconds: elapsedSec,
      autoDiagnosed: true
    };
    setIncidentHistory((prev) => [newRecord, ...prev]);

    // Show resolution toast
    setActiveToast({
      id: `res-${Date.now()}`,
      type: 'resolved',
      title: 'Remediation Verified',
      subtitle: `${cfg.name} · Resolved in ${elapsedSec}s`,
      body: `Executed "${cfg.fixCommand}" (${cfg.runbookId}). Readiness probes returned 200 OK and latency normalized to ${cfg.baseLatencyRange[0] + 2}ms.`,
      timestamp: formatClock(new Date())
    });
  }, [activeServiceId, pipelineStatus, incidentStartTimeMs, appendLog]);

  // Ignore button handler
  const handleIgnoreIncident = useCallback(() => {
    if (!activeServiceId || pipelineStatus !== 'awaiting_approval') return;
    const cfg = SERVICES_CONFIG[activeServiceId];
    const elapsedSec = incidentStartTimeMs
      ? Math.max(10, Math.round((Date.now() - incidentStartTimeMs) / 1000))
      : 24;

    setPipelineStatus('acknowledged');
    appendLog(
      'opspilot-responder',
      'WARN',
      `Engineer acknowledged ${cfg.name} incident without automated fix; service remains degraded.`
    );

    const newRecord: IncidentRecord = {
      id: `INC-${Math.floor(8500 + Math.random() * 499)}`,
      timestamp: `Just now · ${formatClock(new Date())}`,
      serviceId: activeServiceId,
      serviceName: cfg.name,
      severity: cfg.severity,
      rootCause: cfg.rootCauseShort,
      proposedFix: cfg.fixCommand,
      runbookId: cfg.runbookId,
      status: 'Acknowledged',
      resolutionSeconds: elapsedSec,
      autoDiagnosed: true
    };
    setIncidentHistory((prev) => [newRecord, ...prev]);

    setActiveToast({
      id: `ack-${Date.now()}`,
      type: 'acknowledged',
      title: 'Incident Acknowledged',
      subtitle: `${cfg.name} · Manual Investigation`,
      body: `Automated fix "${cfg.fixCommand}" was deferred. ${cfg.name} remains in failing state.`,
      timestamp: formatClock(new Date())
    });
  }, [activeServiceId, pipelineStatus, incidentStartTimeMs, appendLog]);

  // Send Test Telegram Alert from Settings Drawer
  const handleSendTestAlert = useCallback(async () => {
    setIsSendingTestAlert(true);
    const testMessage = [
      '🚨 OpsPilot Alert',
      'Service: API Gateway (Synthetic Test)',
      'Severity: High',
      'Root cause: Manual webhook verification triggered from Control Room Settings.',
      'Proposed fix: docker restart api-gateway',
      'Open OpsPilot to approve.'
    ].join('\n');

    try {
      const res = await fetch('/api/telegram', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customMessage: testMessage })
      });
      const data = await res.json();
      setActiveToast({
        id: `test-${Date.now()}`,
        type: 'telegram',
        title: 'Telegram · Test Alert',
        subtitle: 'Webhook Verification',
        body: data.alertText || testMessage,
        deliveredVia: data.deliveredVia || 'fallback-toast',
        timestamp: formatClock(new Date())
      });
    } catch {
      setActiveToast({
        id: `test-${Date.now()}`,
        type: 'telegram',
        title: 'Telegram · Test Alert',
        subtitle: 'Webhook Verification',
        body: testMessage,
        deliveredVia: 'fallback-toast',
        timestamp: formatClock(new Date())
      });
    } finally {
      setIsSendingTestAlert(false);
    }
  }, []);

  // Filtered logs
  const displayedLogs =
    logFilter === 'errors'
      ? logs.filter((l) => l.level === 'WARN' || l.level === 'ERROR')
      : logs;

  // Incident History Stats
  const totalIncidents = incidentHistory.length;
  const resolvedIncidents = incidentHistory.filter((i) => i.status === 'Resolved');
  const avgResolutionSec =
    resolvedIncidents.length > 0
      ? Math.round(
          resolvedIncidents.reduce((acc, item) => acc + item.resolutionSeconds, 0) /
            resolvedIncidents.length
        )
      : 0;
  const autoDiagnosedPct =
    totalIncidents > 0
      ? Math.round(
          (incidentHistory.filter((i) => i.autoDiagnosed).length / totalIncidents) * 100
        )
      : 100;

  const getServiceIcon = (id: ServiceId) => {
    switch (id) {
      case 'web':
        return <Globe className="w-4 h-4 text-[#d4a95a]" />;
      case 'api':
        return <Server className="w-4 h-4 text-[#d4a95a]" />;
      case 'database':
        return <Database className="w-4 h-4 text-[#d4a95a]" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] bg-film-grain text-[#e6edf6] relative flex flex-col justify-between">
      {/* Subtle warm radial glow behind the header */}
      <div
        className="pointer-events-none fixed top-0 left-1/2 -translate-x-1/2 w-[920px] h-[340px] rounded-full opacity-20 blur-[120px]"
        style={{
          background: anyIncidentActive
            ? 'radial-gradient(circle, rgba(248,113,113,0.45) 0%, rgba(212,169,90,0.12) 60%, transparent 100%)'
            : 'radial-gradient(circle, rgba(212,169,90,0.35) 0%, rgba(52,211,153,0.1) 60%, transparent 100%)'
        }}
        aria-hidden="true"
      />

      {/* In-App Phone-Style Notification Toast */}
      <PhoneToast
        toast={activeToast}
        onDismiss={() => setActiveToast(null)}
        showFocusButton={pipelineStatus === 'awaiting_approval'}
        onFocusApproval={() => {
          approvalCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }}
      />

      {/* Settings Drawer */}
      <SettingsDrawer
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        telegramEnabled={telegramEnabled}
        onToggleTelegram={setTelegramEnabled}
        onSendTestAlert={handleSendTestAlert}
        isSendingTest={isSendingTestAlert}
        groqConnected={groqConnected}
        telegramConnected={telegramConnected}
      />

      {/* Sticky Editorial Control Room Header */}
      <header className="sticky top-0 z-30 bg-[#0b0f17]/88 backdrop-blur-md border-b border-white/[0.08]">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-3">
          {/* Left: Brand Lockup */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#111723] border border-white/10 flex items-center justify-center shadow-inner">
              <Activity
                className={`w-5 h-5 ${
                  anyIncidentActive ? 'text-[#f87171] animate-pulse' : 'text-[#d4a95a]'
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <span className="text-xl sm:text-2xl font-editorial font-semibold tracking-tight text-white">
                  OpsPilot
                </span>
                <span className="text-slate-600 hidden sm:inline" aria-hidden="true">
                  ·
                </span>
                <span className="text-xs text-slate-400 hidden sm:inline">
                  Autonomous Incident Response
                </span>
              </div>
              <p className="text-[11px] text-slate-400 sm:hidden">
                Autonomous Incident Response
              </p>
            </div>
          </div>

          {/* Center / Right Controls: System Status, Clock, Run Live Demo, Settings */}
          <div className="flex items-center gap-2.5 sm:gap-4">
            {/* System Status Indicator */}
            <div
              className={`px-3 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-2 transition-colors ${
                anyIncidentActive
                  ? 'bg-[#f87171]/12 border-[#f87171]/40 text-[#f87171]'
                  : 'bg-[#34d399]/10 border-[#34d399]/30 text-[#34d399]'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  anyIncidentActive ? 'bg-[#f87171] animate-ping' : 'bg-[#34d399]'
                }`}
              />
              <span className="whitespace-nowrap">
                {anyIncidentActive ? 'Incident Active' : 'All Systems Operational'}
              </span>
            </div>

            {/* Live Clock */}
            <div
              className="hidden md:flex items-center gap-1.5 text-xs font-mono text-slate-300 bg-[#111723] px-3 py-2 rounded-xl border border-white/[0.07]"
              aria-label="Control Room Live Clock"
            >
              <Clock className="w-3.5 h-3.5 text-[#d4a95a]" />
              <span>{currentTime}</span>
            </div>

            {/* Big Run Live Demo Button */}
            <button
              type="button"
              onClick={handleRunLiveDemo}
              disabled={pipelineStatus === 'running' || pipelineStatus === 'executing_fix'}
              className="min-h-[44px] px-4 sm:px-5 py-2 rounded-xl bg-[#d4a95a] hover:bg-[#dfc876] text-[#0b0f17] font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all duration-200 cursor-pointer disabled:opacity-50 shadow-lg shadow-[#d4a95a]/15 whitespace-nowrap shrink-0"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Run Live Demo</span>
            </button>

            {/* Settings Gear Button (min 44px tap target) */}
            <button
              type="button"
              onClick={() => setIsSettingsOpen(true)}
              aria-label="Open Control Room Settings"
              className="min-w-[44px] min-h-[44px] rounded-xl bg-[#111723] hover:bg-white/[0.07] border border-white/10 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer shrink-0"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="relative z-10 max-w-[1400px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-8 flex-1">
        {/* Desktop 2-Column Split: Left (Services + Logs), Right (4-Agent Pipeline + Approval) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          {/* LEFT COLUMN (7 cols on lg): Services Panel + Live Log Stream */}
          <div className="lg:col-span-7 space-y-6">
            {/* 1. Production Services Panel */}
            <section className="space-y-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[11px] uppercase tracking-[0.14em] text-[#d4a95a] font-medium">
                    Production Topology
                  </p>
                  <h2 className="text-xl font-editorial font-semibold text-white mt-0.5">
                    Monitored Services
                  </h2>
                </div>
                <span className="text-xs font-mono text-slate-400 md:hidden">
                  {currentTime}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {(['web', 'api', 'database'] as ServiceId[]).map((id) => {
                  const cfg = SERVICES_CONFIG[id];
                  const status = serviceStatuses[id];
                  const isFailing = status === 'failing';
                  const latency = serviceLatencies[id];
                  const uptime = isFailing ? cfg.failingUptime : cfg.baseUptime;

                  return (
                    <div
                      key={id}
                      className={`p-4 sm:p-5 flex flex-col justify-between transition-all duration-300 ${
                        isFailing ? 'control-card-failing' : 'control-card'
                      }`}
                    >
                      <div>
                        {/* Card Top Row: Service Icon + Live Status Indicator */}
                        <div className="flex items-center justify-between gap-2">
                          <div className="w-8 h-8 rounded-lg bg-white/[0.04] border border-white/[0.08] flex items-center justify-center">
                            {getServiceIcon(id)}
                          </div>

                          <div className="flex items-center gap-1.5 text-xs font-mono">
                            <span
                              className={`w-2 h-2 rounded-full ${
                                isFailing
                                  ? 'bg-[#f87171] animate-ping'
                                  : 'bg-[#34d399]'
                              }`}
                            />
                            <span
                              className={
                                isFailing ? 'text-[#f87171] font-semibold' : 'text-[#34d399]'
                              }
                            >
                              {isFailing ? 'Failing' : 'Healthy'}
                            </span>
                          </div>
                        </div>

                        {/* Service Title & Cluster */}
                        <div className="mt-3">
                          <h3 className="text-base font-editorial font-semibold text-white">
                            {cfg.name}
                          </h3>
                          <p className="text-[11px] font-mono text-slate-400 mt-0.5">
                            {cfg.cluster}
                          </p>
                        </div>

                        {/* Uptime % & Live Latency Metrics */}
                        <div className="mt-4 pt-3 border-t border-white/[0.07] grid grid-cols-2 gap-2">
                          <div>
                            <p className="text-[10px] uppercase tracking-[0.12em] text-slate-400">
                              Uptime
                            </p>
                            <p
                              className={`text-sm font-mono font-semibold mt-0.5 ${
                                isFailing ? 'text-[#fbbf24]' : 'text-slate-100'
                              }`}
                            >
                              {uptime.toFixed(2)}%
                            </p>
                          </div>
                          <div>
                            <p className="text-[10px] uppercase tracking-[0.12em] text-slate-400">
                              Latency
                            </p>
                            <p
                              className={`text-sm font-mono font-semibold mt-0.5 ${
                                isFailing ? 'text-[#f87171]' : 'text-[#34d399]'
                              }`}
                            >
                              {latency} ms
                            </p>
                          </div>
                        </div>

                        {/* Scenario Descriptor */}
                        <p className="mt-3 text-xs text-slate-400 line-clamp-2 min-h-[32px]">
                          {isFailing ? (
                            <span className="text-[#f87171]">
                              Alert: {cfg.failureScenarioTitle}
                            </span>
                          ) : (
                            <span>Scenario: {cfg.failureScenarioTitle}</span>
                          )}
                        </p>
                      </div>

                      {/* Simulate Failure Button (min 44px tap target) */}
                      <button
                        type="button"
                        onClick={() => triggerIncident(id)}
                        disabled={pipelineStatus === 'running' || pipelineStatus === 'executing_fix'}
                        className={`mt-4 w-full min-h-[44px] px-3 py-2 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap ${
                          isFailing
                            ? 'bg-[#f87171]/20 hover:bg-[#f87171]/30 border border-[#f87171]/50 text-[#fecaca]'
                            : 'bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 text-slate-200'
                        }`}
                      >
                        {isFailing ? (
                          <>
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Re-Run Diagnostics</span>
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3.5 h-3.5 text-[#fbbf24]" />
                            <span>Simulate Failure</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* 2. Live Log Stream Panel */}
            <section className="control-card overflow-hidden">
              <div className="px-5 py-4 border-b border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Terminal className="w-4 h-4 text-[#d4a95a]" />
                  <div>
                    <p className="text-[11px] uppercase tracking-[0.14em] text-[#d4a95a] font-medium">
                      Real-Time Telemetry Stream
                    </p>
                    <h2 className="text-base font-editorial font-semibold text-white">
                      Live Server Logs
                    </h2>
                  </div>
                </div>

                {/* Filter Controls */}
                <div className="flex items-center gap-1.5 bg-[#0b0f17] p-1 rounded-xl border border-white/[0.08]">
                  <button
                    type="button"
                    onClick={() => setLogFilter('all')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      logFilter === 'all'
                        ? 'bg-[#1a2334] text-white'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    All ({logs.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setLogFilter('errors')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      logFilter === 'errors'
                        ? 'bg-[#f87171]/20 text-[#f87171]'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Warn &amp; Error (
                    {logs.filter((l) => l.level === 'WARN' || l.level === 'ERROR').length})
                  </button>
                </div>
              </div>

              {/* Monospace Terminal Window */}
              <div
                ref={logContainerRef}
                className="h-[340px] sm:h-[380px] overflow-y-auto p-4 bg-[#080b11] font-mono text-xs space-y-2"
              >
                {displayedLogs.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 space-y-1">
                    <CheckCircle2 className="w-5 h-5 text-[#34d399]/70" />
                    <p>No warning or error log entries recorded in current window.</p>
                  </div>
                ) : (
                  displayedLogs.map((entry) => {
                    const levelColor =
                      entry.level === 'ERROR'
                        ? 'text-[#f87171]'
                        : entry.level === 'WARN'
                        ? 'text-[#fbbf24]'
                        : 'text-slate-400';

                    return (
                      <div
                        key={entry.id}
                        className={`flex items-start gap-2.5 leading-relaxed py-0.5 px-2 rounded ${
                          entry.level === 'ERROR'
                            ? 'bg-[#f87171]/[0.07]'
                            : entry.level === 'WARN'
                            ? 'bg-[#fbbf24]/[0.05]'
                            : ''
                        }`}
                      >
                        <span className="text-slate-500 shrink-0 select-none">
                          {entry.timestamp}
                        </span>
                        <span className={`font-semibold w-12 shrink-0 ${levelColor}`}>
                          {entry.level}
                        </span>
                        <span className="text-[#d4a95a]/80 shrink-0 hidden sm:inline">
                          [{entry.service}]
                        </span>
                        <span
                          className={`break-words ${
                            entry.level === 'ERROR'
                              ? 'text-red-200'
                              : entry.level === 'WARN'
                              ? 'text-amber-100'
                              : 'text-slate-300'
                          }`}
                        >
                          {entry.message}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            </section>
          </div>

          {/* RIGHT COLUMN (5 cols on lg): 4-Agent Pipeline + Approval Card */}
          <div ref={pipelineSectionRef} className="lg:col-span-5">
            <AgentPipeline
              steps={agentSteps}
              activeService={activeServiceId ? SERVICES_CONFIG[activeServiceId] : null}
              pipelineStatus={pipelineStatus}
              executionProgress={executionProgress}
              executionStageText={executionStageText}
              resolutionTimeSec={resolutionTimeSec}
              onApproveFix={handleApproveFix}
              onIgnoreIncident={handleIgnoreIncident}
              onRunLiveDemo={handleRunLiveDemo}
              approvalCardRef={approvalCardRef}
            />
          </div>
        </div>

        {/* 3. Incident History & Session Metrics */}
        <section className="control-card p-5 sm:p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/[0.08] pb-4">
            <div className="flex items-center gap-2.5">
              <History className="w-4 h-4 text-[#d4a95a]" />
              <div>
                <p className="text-[11px] uppercase tracking-[0.14em] text-[#d4a95a] font-medium">
                  Session Audit Ledger
                </p>
                <h2 className="text-xl font-editorial font-semibold text-white mt-0.5">
                  Incident History
                </h2>
              </div>
            </div>

            {/* 3-Metric Stats Row: Total Incidents, Avg Resolution Time, Auto-Diagnosed % */}
            <div className="flex flex-wrap items-center gap-6 sm:gap-8">
              <div>
                <p className="text-[11px] uppercase tracking-[0.12em] text-slate-400">
                  Total Incidents
                </p>
                <p className="text-lg font-mono font-semibold text-white mt-0.5">
                  {totalIncidents}
                </p>
              </div>
              <div className="border-l border-white/[0.08] pl-6">
                <p className="text-[11px] uppercase tracking-[0.12em] text-slate-400">
                  Avg Resolution Time
                </p>
                <p className="text-lg font-mono font-semibold text-[#34d399] mt-0.5">
                  {avgResolutionSec > 0 ? `${avgResolutionSec}s` : '—'}
                </p>
              </div>
              <div className="border-l border-white/[0.08] pl-6">
                <p className="text-[11px] uppercase tracking-[0.12em] text-slate-400">
                  Auto-Diagnosed
                </p>
                <p className="text-lg font-mono font-semibold text-[#d4a95a] mt-0.5">
                  {autoDiagnosedPct}%
                </p>
              </div>
            </div>
          </div>

          {/* Incident List */}
          {incidentHistory.length === 0 ? (
            <div className="py-10 text-center space-y-2">
              <p className="text-sm text-slate-300">No incidents recorded in this session yet.</p>
              <p className="text-xs text-slate-500">
                Simulate a service failure or click &ldquo;Run Live Demo&rdquo; to log an incident.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-white/[0.07]">
              {incidentHistory.map((incident) => (
                <div
                  key={incident.id}
                  className="py-4 first:pt-0 last:pb-0 flex flex-col md:flex-row md:items-center justify-between gap-3"
                >
                  <div className="space-y-1 max-w-3xl">
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-mono font-semibold text-[#d4a95a]">
                        {incident.id}
                      </span>
                      <span className="text-slate-600" aria-hidden="true">·</span>
                      <span className="font-semibold text-white">{incident.serviceName}</span>
                      <span className="text-slate-600" aria-hidden="true">·</span>
                      <span
                        className={`font-mono font-medium ${
                          incident.severity === 'Critical'
                            ? 'text-[#f87171]'
                            : incident.severity === 'High'
                            ? 'text-[#fbbf24]'
                            : 'text-[#34d399]'
                        }`}
                      >
                        {incident.severity} Severity
                      </span>
                      <span className="text-slate-600" aria-hidden="true">·</span>
                      <span className="font-mono text-slate-400">{incident.timestamp}</span>
                    </div>

                    <p className="text-sm text-slate-300">{incident.rootCause}</p>

                    <div className="flex flex-wrap items-center gap-2 pt-0.5 text-xs font-mono text-slate-400">
                      <span>Runbook {incident.runbookId}</span>
                      <span className="text-slate-600" aria-hidden="true">/</span>
                      <code className="text-[#34d399]">{incident.proposedFix}</code>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0 text-xs font-mono">
                    {incident.status === 'Resolved' ? (
                      <div className="flex items-center gap-2 text-[#34d399]">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Resolved in {incident.resolutionSeconds}s</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-[#fbbf24]">
                        <AlertTriangle className="w-4 h-4" />
                        <span>Acknowledged ({incident.resolutionSeconds}s)</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/[0.08] py-5 mt-8">
        <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
          <span>OpsPilot · Multi-agent incident response</span>
          <span className="font-mono text-[11px] text-slate-500">
            Monitor · Triage · Diagnose · Responder
          </span>
        </div>
      </footer>
    </div>
  );
}
