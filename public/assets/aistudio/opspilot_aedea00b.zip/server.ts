import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

type ServiceId = 'web' | 'api' | 'database';
type AgentRole = 'monitor' | 'triage' | 'diagnose' | 'responder';

// Single model configuration object at the top of the server file for easy customization
const AGENT_MODEL_CONFIG = {
  fastModel: 'llama-3.1-8b-instant',
  reasoningModel: 'llama-3.3-70b-versatile',
  routes: {
    monitor: 'llama-3.1-8b-instant',
    triage: 'llama-3.1-8b-instant',
    diagnose: 'llama-3.3-70b-versatile',
    responder: 'llama-3.3-70b-versatile'
  } as Record<AgentRole, string>
};

interface ScenarioFallback {
  severity: 'Low' | 'High' | 'Critical';
  userImpact: string;
  runbookId: string;
  runbookTitle: string;
  fixCommand: string;
  rootCauseShort: string;
  responses: Record<AgentRole, string>;
}

const SCENARIO_FALLBACKS: Record<ServiceId, ScenarioFallback> = {
  web: {
    severity: 'High',
    userImpact: '~38% of edge HTTP requests returning 502 Bad Gateway across US-East and EU-Central.',
    runbookId: 'RB-101',
    runbookTitle: 'SSR Worker Heap Exhaustion & 502 Gateway Recovery',
    fixCommand: 'docker restart web-frontend-ssr',
    rootCauseShort: 'Unbounded SSR V8 heap allocation leak causing worker OOM kills and upstream 502 responses.',
    responses: {
      monitor:
        'Detected a sharp anomaly on Web Frontend: HTTP 502 Bad Gateway responses spiked to 38.4% as p99 latency climbed past 2,480ms. V8 heap utilization on SSR worker nodes crossed 98.7% immediately prior to upstream socket hang-ups.',
      triage:
        'Assigned High severity due to active customer-facing 502 errors degrading checkout and session rendering across primary edge POPs. Estimated user impact is ~38% of active web sessions experiencing render timeouts, though static CDN assets remain unaffected.',
      diagnose:
        'Root cause traced to an unbounded SSR cache closure in v2.14.3 exhausting the 2048MB Node.js worker heap and triggering Linux OOM-killer termination. Matched incident signature to Runbook RB-101 (SSR Worker Heap Exhaustion), which prescribes a rolling container restart via "docker restart web-frontend-ssr".',
      responder:
        'Web Frontend is experiencing High-severity 502 Bad Gateway errors caused by SSR worker V8 heap exhaustion matching Runbook RB-101. I have staged "docker restart web-frontend-ssr" to recycle the leaking worker containers and restore healthy upstream sockets. Dispatching on-call Telegram alert now and awaiting engineer approval to execute.'
    }
  },
  api: {
    severity: 'Critical',
    userImpact: '~74% of authenticated API calls failing with 429/504 cascade across mobile and web clients.',
    runbookId: 'RB-204',
    runbookTitle: 'API Gateway Token Bucket Saturation & Timeout Cascade',
    fixCommand: 'docker restart api-gateway',
    rootCauseShort: 'Rate-limit token bucket lock contention triggering upstream worker pool starvation and 504 timeout cascade.',
    responses: {
      monitor:
        'Detected a critical anomaly on API Gateway: rate-limiter token bucket exhaustion coincides with a retry storm of 14,200 req/s and p99 latency surging to 3,920ms. Upstream worker threads are deadlocked waiting on stalled Envoy circuit-breaker sockets.',
      triage:
        'Assigned Critical severity because core authentication and transaction mutations are failing across both web and mobile clients. Estimated user impact is ~74% of synchronous API traffic dropping with 429 Too Many Requests and 504 Gateway Timeout errors.',
      diagnose:
        'Root cause identified as a retry amplification loop exhausting the Redis-backed rate limit bucket and starving the Envoy worker thread pool. Matched telemetry signature to Runbook RB-204 (API Gateway Rate-Limit & Timeout Cascade), which specifies executing "docker restart api-gateway" to flush wedged worker sockets and reset circuit breakers.',
      responder:
        'API Gateway is in a Critical timeout cascade triggered by token bucket lock contention and client retry amplification (Runbook RB-204). I have prepared "docker restart api-gateway" to drain deadlocked worker threads and re-initialize rate-limit token buckets. Sending Telegram alert to the on-call engineer for immediate remediation approval.'
    }
  },
  database: {
    severity: 'Critical',
    userImpact: '92% of write transactions blocked; global read-replica lag exceeding 18.4 seconds.',
    runbookId: 'RB-309',
    runbookTitle: 'PostgreSQL Connection Pool Exhaustion & Lock Remediation',
    fixCommand: 'docker restart pgbouncer-pooler',
    rootCauseShort: 'Orphaned idle-in-transaction locks saturating all 500 PostgreSQL connection slots.',
    responses: {
      monitor:
        'Detected a severe database telemetry anomaly: active PostgreSQL connections hit 500/500 (100% pool saturation) with 412 sessions stuck in "idle in transaction". Query execution latency spiked from 6ms to 4,650ms with FATAL connection slot exhaustion errors.',
      triage:
        'Assigned Critical severity as primary database write capacity is effectively halted and read replicas are lagging by 18.4 seconds. Estimated user impact covers 92% of state-mutating requests failing across all downstream services.',
      diagnose:
        'Root cause is an unclosed batch-reporting transaction holding row-level locks on "orders_ledger" and blocking PgBouncer from recycling backend slots. Matched directly to Runbook RB-309 (PostgreSQL Connection Pool Exhaustion), which prescribes running "docker restart pgbouncer-pooler" to terminate orphaned idle transactions and reclaim connection slots.',
      responder:
        'Database is suffering Critical connection pool exhaustion (500/500 slots occupied by orphaned idle-in-transaction locks), matched to Runbook RB-309. I recommend executing "docker restart pgbouncer-pooler" to sever stalled backend transactions and restore pool headroom. Alerting on-call engineer on Telegram and holding for approval.'
    }
  }
};

function hasValidGroqKey(): boolean {
  const key = process.env.GROQ_API_KEY?.trim();
  return Boolean(key && key !== 'MY_GROQ_API_KEY' && key.length > 10);
}

function hasValidTelegramConfig(): boolean {
  const token = process.env.TELEGRAM_BOT_TOKEN?.trim();
  const chatId = process.env.TELEGRAM_CHAT_ID?.trim();
  return Boolean(
    token &&
      chatId &&
      token !== 'MY_TELEGRAM_BOT_TOKEN' &&
      chatId !== 'MY_TELEGRAM_CHAT_ID'
  );
}

function sanitizeGroqOutput(raw: string): string {
  const withoutThink = raw.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  return withoutThink
    .replace(/\*\*/g, '')
    .replace(/^#+\s*/gm, '')
    .replace(/\n+/g, ' ')
    .trim();
}

async function generateWithGroq(
  role: AgentRole,
  prompt: string,
  systemInstruction: string
): Promise<{ text: string; modelUsed: string; latencyMs: number } | null> {
  if (!hasValidGroqKey()) return null;

  const apiKey = process.env.GROQ_API_KEY!.trim();
  const primaryModel = AGENT_MODEL_CONFIG.routes[role];
  const alternateModel =
    primaryModel === AGENT_MODEL_CONFIG.fastModel
      ? AGENT_MODEL_CONFIG.reasoningModel
      : AGENT_MODEL_CONFIG.fastModel;

  // Fallback chain: try assigned primary model first; if it fails or hits a rate limit, retry once with the other model
  const modelsToTry = [primaryModel, alternateModel];

  for (const modelName of modelsToTry) {
    const callStart = Date.now();
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);

      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: modelName,
          messages: [
            { role: 'system', content: systemInstruction },
            { role: 'user', content: prompt }
          ],
          temperature: 0.2,
          max_tokens: 240
        }),
        signal: controller.signal
      });

      clearTimeout(timeout);

      // If rate-limited (429) or server error, continue to retry once with the other model
      if (!response.ok) {
        continue;
      }

      const data = (await response.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
      };
      const rawContent = data?.choices?.[0]?.message?.content;
      if (rawContent) {
        const cleaned = sanitizeGroqOutput(rawContent);
        if (cleaned.length > 15) {
          return {
            text: cleaned,
            modelUsed: modelName,
            latencyMs: Math.max(120, Date.now() - callStart)
          };
        }
      }
    } catch {
      // Retry with the other model in modelsToTry, or fall back to pre-written response
    }
  }

  return null;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // 1. Health & Secret Connection Status Endpoint (never exposes keys)
  app.get('/api/status', (_req, res) => {
    res.json({
      ok: true,
      groqConnected: hasValidGroqKey(),
      telegramConnected: hasValidTelegramConfig(),
      models: AGENT_MODEL_CONFIG.routes,
      timestamp: new Date().toISOString()
    });
  });

  // 2. Multi-Agent Step Endpoint powered by Groq OpenAI-compatible API
  app.post('/api/agent', async (req, res) => {
    const {
      agentRole,
      serviceId = 'api',
      serviceName = 'API Gateway',
      scenarioTitle = 'Rate limit exhausted + timeout cascade',
      logs = [],
      previousOutputs = {}
    } = req.body as {
      agentRole: AgentRole;
      serviceId?: ServiceId;
      serviceName?: string;
      scenarioTitle?: string;
      logs?: string[];
      previousOutputs?: Partial<Record<AgentRole, string>>;
    };

    const validServiceId: ServiceId =
      serviceId === 'web' || serviceId === 'api' || serviceId === 'database'
        ? serviceId
        : 'api';
    const validRole: AgentRole =
      agentRole === 'monitor' ||
      agentRole === 'triage' ||
      agentRole === 'diagnose' ||
      agentRole === 'responder'
        ? agentRole
        : 'monitor';

    const scenario = SCENARIO_FALLBACKS[validServiceId];
    const fallbackOutput = scenario.responses[validRole];
    const configuredModel = AGENT_MODEL_CONFIG.routes[validRole];

    const systemInstruction = [
      'You are an autonomous AI Site Reliability Engineering agent inside OpsPilot.',
      'Respond in plain text only (no markdown bold, no bullet lists, no code fences).',
      'Write a maximum of 3 concise, high-signal sentences in a calm, authoritative on-call engineer tone.',
      'Include concrete metrics from the logs or runbook where relevant.'
    ].join(' ');

    const recentLogsText = Array.isArray(logs) ? logs.slice(-10).join('\n') : '';
    const prevContext = Object.entries(previousOutputs)
      .map(([role, text]) => `${role.toUpperCase()} AGENT: ${text}`)
      .join('\n');

    const rolePrompts: Record<AgentRole, string> = {
      monitor: `You are the Monitor Agent. Inspect the following error logs for service "${serviceName}" (Scenario: ${scenarioTitle}) and state clearly what telemetry anomaly and error rate spike you detected.\n\nLogs:\n${recentLogsText}`,
      triage: `You are the Triage Agent. Based on the Monitor Agent's findings below for "${serviceName}", assign severity "${scenario.severity}" with a crisp one-line engineering justification and state the estimated user impact (${scenario.userImpact}).\n\nPrevious context:\n${prevContext}`,
      diagnose: `You are the Diagnose Agent. Based on the context below for "${serviceName}", explain the technical root cause (${scenario.rootCauseShort}) and match it to Built-in Runbook ${scenario.runbookId} ("${scenario.runbookTitle}") with proposed fix command "${scenario.fixCommand}".\n\nPrevious context:\n${prevContext}`,
      responder: `You are the Responder Agent. Synthesize the final incident summary for "${serviceName}", confirm the staged remediation command "${scenario.fixCommand}" from Runbook ${scenario.runbookId}, and state that the Telegram alert has been dispatched to the on-call engineer awaiting approval.\n\nPrevious context:\n${prevContext}`
    };

    const groqResult = await generateWithGroq(
      validRole,
      rolePrompts[validRole],
      systemInstruction
    );

    // Realistic fallback latency (fast ~380-480ms for 8b, ~640-780ms for 70b) when using pre-written fallback
    const defaultLatencyMs =
      configuredModel === AGENT_MODEL_CONFIG.fastModel ? 410 : 680;

    res.json({
      ok: true,
      agentRole: validRole,
      serviceId: validServiceId,
      model: groqResult?.modelUsed || configuredModel,
      latencyMs: groqResult?.latencyMs || defaultLatencyMs,
      output: groqResult?.text || fallbackOutput,
      usedFallback: !groqResult,
      metadata: {
        severity: scenario.severity,
        userImpact: scenario.userImpact,
        runbookId: scenario.runbookId,
        runbookTitle: scenario.runbookTitle,
        fixCommand: scenario.fixCommand,
        rootCauseShort: scenario.rootCauseShort
      }
    });
  });

  // 3. Telegram Bot Alert Endpoint
  app.post('/api/telegram', async (req, res) => {
    const {
      serviceName = 'API Gateway',
      severity = 'Critical',
      rootCause = 'Rate-limit token bucket lock contention triggering upstream 504 timeout cascade.',
      proposedFix = 'docker restart api-gateway',
      customMessage
    } = req.body as {
      serviceName?: string;
      severity?: string;
      rootCause?: string;
      proposedFix?: string;
      customMessage?: string;
    };

    const alertText =
      customMessage ||
      [
        '🚨 OpsPilot Alert',
        `Service: ${serviceName}`,
        `Severity: ${severity}`,
        `Root cause: ${rootCause}`,
        `Proposed fix: ${proposedFix}`,
        'Open OpsPilot to approve.'
      ].join('\n');

    if (hasValidTelegramConfig()) {
      const token = process.env.TELEGRAM_BOT_TOKEN!.trim();
      const chatId = process.env.TELEGRAM_CHAT_ID!.trim();
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 4500);

        const tgRes = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: alertText
          }),
          signal: controller.signal
        });
        clearTimeout(timer);

        if (tgRes.ok) {
          res.json({
            ok: true,
            deliveredVia: 'telegram',
            alertText,
            timestamp: new Date().toISOString()
          });
          return;
        }
      } catch {
        // Fall through to graceful in-app notification toast
      }
    }

    // Graceful fallback so the demo never breaks
    res.json({
      ok: true,
      deliveredVia: 'fallback-toast',
      alertText,
      timestamp: new Date().toISOString()
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`OpsPilot server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
